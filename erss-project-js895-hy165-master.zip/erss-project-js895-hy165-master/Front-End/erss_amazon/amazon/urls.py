from django.urls import include, path
from . import views

urlpatterns = [

    path('home/', views.home, name = "home"),
    path('catalogue/', views.CatalogueView, name = "catalogue"),
    path('place_order/', views.place_order, name = "place_order"),
    path('orders/', views.OrdersView.as_view(), name = "orders"),
    path('orders/<int:order_id>/', views.order_details, name = "order_details"),
]