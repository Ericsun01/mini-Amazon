from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView, DetailView
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from django.shortcuts import redirect
from django.db.models import Q
from .forms import RegisterForm, PlaceOrderForm
from .models import AmazonUser, Department, Products, Orders

import socket
 
    
TCP_IP = 'vcm-13673.vm.duke.edu'
TCP_PORT = 5678
BUFFER_SIZE = 128
MESSAGE = "New order placed!"


# helper functions
def is_valid_query(param):
    return param != '' and param is not None


def index(request):
    return render(request, 'amazon/index.html')

def login(request):
    return render(request, 'amazon/login.html')

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, 'Account created successfully!')
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, 'amazon/register.html', {'form': form})

# home page
@login_required
def home(request):
    return render(request, 'amazon/home.html')

# product list page
@login_required
def CatalogueView(request):
    qs = Products.objects.all()
    departments = Department.objects.all()
    product_name_query = request.GET.get('product_name')
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    department = request.GET.get('department')

    if is_valid_query(product_name_query):
        qs = qs.filter(name__icontains=product_name_query)
    
    if is_valid_query(min_price):
        qs = qs.filter(price__gte=min_price)

    if is_valid_query(max_price):
        qs = qs.filter(price__lte=max_price)

    if is_valid_query(department) and department != 'Choose...':
        qs = qs.filter(department__name=department)


    context = {
        'queryset': qs,
        'departments': departments,
    }

    return render(request, 'amazon/catalogue.html', context)

# place order page
@login_required
def place_order(request):
    form = PlaceOrderForm()
    if request.method == 'POST':
        form = PlaceOrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.owner = request.user           
            # create socket and notify
            order.save()

            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((TCP_IP, TCP_PORT))
            print("Connected")
            order_id = str(order.id)
            print(order_id)
            s.send(order_id.encode())
            # data = s.recv(BUFFER_SIZE)
            s.close()

            return redirect('home')
        else:
            form = PlaceOrderForm()

    return render(request, 'amazon/place_order.html', {'form': form})



# list of orders
class OrdersView(ListView):
    model = Orders
    template_name = 'amazon/orders.html'
    context_object_name = 'Orders'

    def get_queryset(self):
        return Orders.objects.filter(owner=self.request.user)

# order details
@login_required
def order_details(request, order_id):
    order = get_object_or_404(Orders, pk=order_id)
    context = {'order': order}
    return render(request, 'amazon/order_details.html', context)

# @login_required
# def logout(request):
#     return redirect('login')


