from django.db import models
from django.contrib.auth.models import AbstractUser

# amazon user
class AmazonUser(AbstractUser):
    ups_username = models.CharField(max_length=100, blank=False, default='xxx')

    def __str__(self):
        return self.username

# department
class Department(models.Model):
    name = models.CharField(max_length=20)

    def __str__(self):
        return self.name

# products
class Products(models.Model): # products list
    name = models.CharField(max_length=300) # name of product
    department = models.ManyToManyField(Department) # add-on. Could delete if needed.
    price = models.DecimalField(max_digits=10, decimal_places=2) # price of product
    wh_id = models.IntegerField(null=True) # the warehouse where it is stored

    def __str__(self):
        return self.name

# orders
class Orders(models.Model): 
    owner = models.ForeignKey(AmazonUser, on_delete=models.CASCADE)
    description = models.ForeignKey(Products, on_delete=models.CASCADE, null=True) # name of product
    count = models.IntegerField(default=0) # number of product
    ship_addr_x = models.IntegerField(default=0) # x coordinate of shipping address
    ship_addr_y = models.IntegerField(default=0) # y coordinate of shipping address
    ship_id = models.IntegerField(null=True) # i.e. order number()
    truck_id = models.IntegerField(null=True)
    status = models.CharField(max_length=100, default='Confirmed')

    def __str__(self):
        return str(self.description) if self.description else ''