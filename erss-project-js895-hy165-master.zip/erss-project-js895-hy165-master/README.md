# erss-project-js895-hy165

### Front end:
Under Front-End/erss_amazon:
    python3 manage.py 0.0.0.0:8000 to execute

### Back end:
Under Back-End:
    ./amazon

